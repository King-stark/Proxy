#ifndef HAPROXYTHREAD_H
#define HAPROXYTHREAD_H

#include <QObject>

class HaproxyThread
{
public:
    HaproxyThread();
};

#endif // HAPROXYTHREAD_H
