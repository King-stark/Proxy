#include <Windows.h>

#ifdef __cplusplus
extern "C"
{
#endif

int setProxy(int method, LPTSTR server);

#ifdef __cplusplus
}
#endif
