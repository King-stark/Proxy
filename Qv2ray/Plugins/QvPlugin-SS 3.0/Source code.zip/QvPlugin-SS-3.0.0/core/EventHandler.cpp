#include "EventHandler.hpp"

SSPluginEventHandler::SSPluginEventHandler() : Qv2rayPlugin::PluginEventHandler()
{
}
