# QvPlugin-SS
适用于 Qv2ray 的 ShadowSocks 插件，使用此插件在 Qv2ray 中启用 SIP003 完整支持
