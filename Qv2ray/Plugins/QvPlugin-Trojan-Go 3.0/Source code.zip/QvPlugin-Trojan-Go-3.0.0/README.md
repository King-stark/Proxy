# QvPlugin-Trojan-Go
> 适用于 Qv2ray v2.6+ 的 Trojan-Go 插件

感谢 [@p4gefault](https://github.com/p4gefau1t) 的 [Trojan-Go](https://github.com/p4gefau1t/trojan-go) 项目～

使用方法请参见 [Qv2ray 插件文档](https://qv2ray.github.io/plugins/usage.html)。
