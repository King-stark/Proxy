#pragma once
#include "QvPluginProcessor.hpp"

class NaiveEventHandler : public Qv2rayPlugin::PluginEventHandler
{
  public:
    NaiveEventHandler();
};
