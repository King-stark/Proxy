#include "EventHandler.hpp"

using namespace Qv2rayPlugin;
NaiveEventHandler::NaiveEventHandler() : Qv2rayPlugin::PluginEventHandler()
{
}
