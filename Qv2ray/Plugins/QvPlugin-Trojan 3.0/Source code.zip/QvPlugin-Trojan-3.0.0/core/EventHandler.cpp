#include "EventHandler.hpp"

using namespace Qv2rayPlugin;
TrojanEventHandler::TrojanEventHandler() : Qv2rayPlugin::PluginEventHandler()
{
}
