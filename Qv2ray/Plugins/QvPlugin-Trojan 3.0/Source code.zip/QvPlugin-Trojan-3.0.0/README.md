# QvPlugin-Trojan
> Use Trojan-GFW in Qv2ray.

## Usage
1. Download
2. Put Plugin into Plugin Directory
3. Restart Qv2ray to reload plugins
4. Enjoy!
