#pragma once
#include "QvPluginProcessor.hpp"

class TrojanEventHandler : public Qv2rayPlugin::PluginEventHandler
{
  public:
    TrojanEventHandler();
};
