# QvPlugin-SSR
适用于 Qv2ray 的 ShadowSocksR 插件，使用此插件在 Qv2ray 中启用 SSR 功能
