#include "EventHandler.hpp"

SSRPluginEventHandler::SSRPluginEventHandler() : Qv2rayPlugin::PluginEventHandler()
{
}
