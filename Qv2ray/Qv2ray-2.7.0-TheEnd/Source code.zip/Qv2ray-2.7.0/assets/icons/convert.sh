#!/bin/bash
#sed -i "s/#dbdbdb/#707070/g" *.svg
