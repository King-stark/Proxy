#include "Qv2rayQMLProperty.hpp"

Qv2rayQMLProperty::Qv2rayQMLProperty(QObject *parent) : QObject(parent)
{
}
